# Mayra's 2nd Birthday Invitation Website

## Overview

This is a multi-page birthday invitation website for Mayra's 2nd birthday celebration. The application is built as a modern web app with a React frontend and Express backend, designed to showcase different events throughout the celebration day including Bhandara, Mata Rani Kirtan, and the main birthday party.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom birthday theme colors
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query for server state management
- **Fonts**: Poppins and Inter for typography

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Module System**: ES Modules
- **Development**: tsx for TypeScript execution in development
- **Build**: esbuild for production bundling
- **Error Handling**: Centralized error middleware

### Database & ORM
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema**: Currently includes basic user management schema
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Pages
1. **HomePage** (`/`) - Main landing page with Mayra's photo and event overview
2. **BhandaraPage** (`/bhandara`) - Divine beginning ceremony details
3. **KirtanPage** (`/kirtan`) - Mata Rani Kirtan event information
4. **BirthdayPage** (`/birthday`) - Main birthday celebration with cake cutting and dinner

### Shared Components
- **Navigation** - Fixed top navigation with event tabs
- **Footer** - Contact information and family sign-off

### UI System
- **Design System**: Shadcn/ui with custom birthday theme
- **Color Palette**: Pink, purple, saffron, and cream tones for festive atmosphere
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints

## Data Flow

### Current Implementation
- Static content presentation with no dynamic data requirements
- Client-side routing between event pages
- Responsive image placeholders from Unsplash for visual appeal

### Backend Structure
- Express server with route registration system
- Memory storage implementation for future user features
- Middleware for request logging and error handling

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless** - Database connectivity
- **@tanstack/react-query** - Server state management
- **wouter** - Lightweight routing
- **drizzle-orm** & **drizzle-zod** - Database ORM and validation
- **@radix-ui/react-*** - Accessible UI primitives
- **tailwindcss** - Utility-first CSS framework
- **lucide-react** - Icon library

### Development Tools
- **vite** - Build tool and dev server
- **tsx** - TypeScript execution
- **esbuild** - Production bundling
- **@replit/vite-plugin*** - Replit-specific development features

## Deployment Strategy

### Development
- Vite dev server with HMR for frontend
- tsx for running TypeScript backend in development
- Replit-specific plugins for enhanced development experience

### Production Build
1. Frontend: Vite builds React app to `dist/public`
2. Backend: esbuild bundles Express server to `dist/index.js`
3. Static file serving: Express serves built frontend files
4. Environment: NODE_ENV=production for optimizations

### Database Setup
- PostgreSQL database through Neon serverless
- Drizzle migrations stored in `./migrations`
- Schema defined in `shared/schema.ts`
- Push migrations with `npm run db:push`

### Environment Variables
- `DATABASE_URL` - Required for database connection
- `NODE_ENV` - Environment mode (development/production)
- `REPL_ID` - Replit-specific identifier for development features

The application follows a monorepo structure with clear separation between client, server, and shared code, making it maintainable and scalable for future enhancements like RSVP functionality or photo uploads.