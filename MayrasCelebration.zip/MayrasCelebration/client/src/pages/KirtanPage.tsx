import { Clock, MapPin, Music } from "lucide-react";

export default function KirtanPage() {
  const musicalElements = [
    { emoji: "🥁", title: "Tabla Beats", subtitle: "Rhythmic devotion" },
    { emoji: "🎹", title: "Harmonium", subtitle: "Melodic prayers" },
    { emoji: "🔔", title: "Sacred Bells", subtitle: "Divine resonance" },
  ];

  return (
    <div className="pt-20">
      <div className="bg-gradient-to-br from-deep-orange/20 via-saffron/20 to-golden-yellow/20 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 py-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-block animate-bounce-slow">
              <h1 className="text-4xl md:text-5xl font-poppins font-bold text-saffron mb-4">
                🎤 Mata Rani Kirtan
              </h1>
            </div>

          </div>

          {/* Event Details */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl p-8 mb-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="text-center p-6 bg-gradient-to-br from-deep-orange/10 to-saffron/10 rounded-2xl">
                <MapPin className="w-8 h-8 mx-auto mb-2 text-deep-orange" />
                <div className="text-4xl mb-4">📍</div>
                <h3 className="font-poppins font-semibold text-xl text-gray-800 mb-3">Location</h3>
                <p className="text-gray-700 font-medium">H Block - Parking Area</p>
                <p className="text-gray-600">SSA Society</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-saffron/10 to-golden-yellow/10 rounded-2xl">
                <Clock className="w-8 h-8 mx-auto mb-2 text-saffron" />
                <div className="text-4xl mb-4">🕒</div>
                <h3 className="font-poppins font-semibold text-xl text-gray-800 mb-3">Time</h3>
                <p className="text-gray-700 font-medium text-2xl">3:00 PM</p>
                <p className="text-gray-600">Divine Music</p>
              </div>
            </div>
          </div>

          {/* Devotional Message */}
          <div className="bg-gradient-to-r from-saffron/20 via-deep-orange/20 to-golden-yellow/20 rounded-3xl p-8 mb-8">
            <div className="text-center">
              <Music className="w-12 h-12 mx-auto mb-4 text-deep-orange" />
              <div className="text-5xl mb-4">🎵</div>
              <h3 className="text-2xl font-poppins font-semibold text-gray-800 mb-4">Join the Divine Melody</h3>
              <p className="text-lg text-gray-700 leading-relaxed italic">
                "Come, sing along and spread divine energy with us."
              </p>
            </div>
          </div>

          {/* Musical Elements */}
          <div className="grid md:grid-cols-3 gap-6">
            {musicalElements.map((element, index) => (
              <div key={index} className="text-center p-6 bg-white/80 rounded-2xl shadow-lg">
                <div className="text-3xl mb-3">{element.emoji}</div>
                <h4 className="font-poppins font-semibold">{element.title}</h4>
                <p className="text-sm text-gray-600 mt-2">{element.subtitle}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
