import { Clock, MapPin, Camera } from "lucide-react";
import mayraPhoto2 from "@assets/2nd_1753082326397.jpeg";
import mayraPhoto3 from "@assets/3rd_1753082326398.jpeg";
import mayraPhoto4 from "@assets/4th_1753082326399.jpeg";
import mayraPhoto5 from "@assets/5th_1753082326400.jpeg";

export default function BirthdayPage() {
  const partyElements = [
    { emoji: "🎂", title: "Princess Cake" },
    { emoji: "🎈", title: "Pink Balloons" },
    { emoji: "✨", title: "Princess Theme" },
    { emoji: "🎁", title: "Special Gifts" },
  ];

  const mayraPhotos = [
    {
      src: mayraPhoto2,
      alt: "Mayra's beautiful moments - Photo 2"
    },
    {
      src: mayraPhoto3,
      alt: "Mayra's beautiful moments - Photo 3"
    },
    {
      src: mayraPhoto4,
      alt: "Mayra's beautiful moments - Photo 4"
    },
    {
      src: mayraPhoto5,
      alt: "Mayra's beautiful moments - Photo 5"
    },
  ];

  return (
    <div className="pt-20">
      <div className="bg-gradient-to-br from-birthday-pink/20 via-pastel-pink/20 to-soft-purple/20 min-h-screen">
        <div className="max-w-6xl mx-auto px-4 py-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-block animate-float">
              <h1 className="text-4xl md:text-6xl font-poppins font-bold text-birthday-pink mb-4">
                🎉 Birthday Celebration 🎉
              </h1>
              <h2 className="text-xl md:text-2xl font-poppins font-semibold text-soft-purple">
                ✨ Premium Princess Party ✨
              </h2>
            </div>
          </div>

          {/* Event Timeline */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl p-8 mb-8">
            <h3 className="text-2xl font-poppins font-semibold text-center text-gray-800 mb-8">🕒 Celebration Timeline</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-gradient-to-br from-birthday-pink/10 to-pastel-pink/10 rounded-2xl">
                <MapPin className="w-8 h-8 mx-auto mb-2 text-birthday-pink" />
                <div className="text-4xl mb-4">📍</div>
                <h4 className="font-poppins font-semibold text-lg text-gray-800 mb-2">Location</h4>
                <p className="text-gray-700 font-medium">H Block - Parking Area</p>
                <p className="text-gray-600">SSA Society</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-soft-purple/10 to-lavender/10 rounded-2xl">
                <Clock className="w-8 h-8 mx-auto mb-2 text-soft-purple" />
                <div className="text-4xl mb-4">🕖</div>
                <h4 className="font-poppins font-semibold text-lg text-gray-800 mb-2">Cake Cutting</h4>
                <p className="text-gray-700 font-medium text-xl">7:31 PM</p>
                <p className="text-gray-600">Princess moment!</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-pastel-pink/10 to-rose-gold/10 rounded-2xl">
                <div className="text-4xl mb-4">🍽️</div>
                <h4 className="font-poppins font-semibold text-lg text-gray-800 mb-2">Dinner</h4>
                <p className="text-gray-700 font-medium text-xl">8:00 PM</p>
                <p className="text-gray-600">Delicious feast</p>
              </div>
            </div>
          </div>

          {/* Photo Gallery */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 mb-8">
            <h3 className="text-2xl font-poppins font-semibold text-center text-gray-800 mb-8">
              <Camera className="inline-block w-6 h-6 mr-2" />
              📸 Mayra's Beautiful Moments
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {mayraPhotos.map((photo, index) => (
                <div
                  key={index}
                  className="relative group overflow-hidden rounded-2xl shadow-lg transform hover:scale-105 transition-transform duration-300"
                >
                  <img
                    src={photo.src}
                    alt={photo.alt}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-birthday-pink/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              ))}
            </div>
          </div>

          {/* Celebration Message */}
          <div className="bg-gradient-to-r from-birthday-pink/20 via-pastel-pink/20 to-soft-purple/20 rounded-3xl p-8 mb-8">
            <div className="text-center">
              <div className="text-5xl mb-4">🎂</div>
              <h3 className="text-2xl font-poppins font-semibold text-gray-800 mb-4">Join Our Princess Party!</h3>
              <p className="text-lg text-gray-700 leading-relaxed">
                "Join us for cake, laughter, and a delicious dinner."
              </p>
            </div>
          </div>

          {/* Party Elements */}
          <div className="grid md:grid-cols-4 gap-4">
            {partyElements.map((element, index) => (
              <div key={index} className="text-center p-4 bg-white/80 rounded-2xl shadow-lg">
                <div className="text-3xl mb-2">{element.emoji}</div>
                <h4 className="font-poppins font-semibold text-sm">{element.title}</h4>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
