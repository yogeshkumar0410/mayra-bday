import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, ExternalLink } from "lucide-react";
import mayraMainPhoto from "@assets/1st_1753082326396.jpeg";

export default function HomePage() {
  const [, setLocation] = useLocation();

  const quickEvents = [
    {
      title: "Bhandara",
      time: "11:30 AM",
      subtitle: "Divine Beginning",
      emoji: "🌼",
      path: "/bhandara",
      bgColor: "from-saffron/10 to-golden-yellow/10",
    },
    {
      title: "Mata Rani Kirtan",
      time: "3:00 PM",
      subtitle: "Divine Energy",
      emoji: "🎤",
      path: "/kirtan",
      bgColor: "from-deep-orange/10 to-saffron/10",
    },
    {
      title: "Birthday Celebration",
      time: "7:31 PM",
      subtitle: "Cake & Dinner",
      emoji: "🎉",
      path: "/birthday",
      bgColor: "from-birthday-pink/10 to-soft-purple/10",
    },
  ];

  return (
    <div className="pt-20">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-block animate-float">
            <h1 className="text-4xl md:text-6xl font-poppins font-bold text-birthday-pink mb-4">
              🎀 Mayra Turns 2! 🎀
            </h1>
            <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-soft-purple mb-6">
              ✨ You're Invited! ✨
            </h2>
          </div>
          
          {/* Main Photo - Mayra */}
          <div className="max-w-md mx-auto mb-8">
            <div className="relative overflow-hidden rounded-3xl shadow-2xl transform hover:scale-105 transition-transform duration-300">
              <img 
                src={mayraMainPhoto}
                alt="Our Little Princess Mayra - 2nd Birthday" 
                className="w-full h-80 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-birthday-pink/20 to-transparent"></div>
              <div className="absolute bottom-4 left-4 right-4">
                <div className="bg-white/90 rounded-2xl p-3 text-center">
                  <p className="text-birthday-pink font-poppins font-semibold text-lg">Our Little Princess Mayra</p>
                </div>
              </div>
            </div>
          </div>

          {/* Key Details Card */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 mb-8 border border-pastel-pink/30">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="text-center p-4 bg-gradient-to-br from-birthday-pink/10 to-pastel-pink/10 rounded-2xl">
                <Calendar className="w-8 h-8 mx-auto mb-2 text-birthday-pink" />
                <div className="text-3xl mb-2">📆</div>
                <h3 className="font-poppins font-semibold text-lg text-gray-800 mb-2">Date</h3>
                <p className="text-gray-600 font-medium">26th July 2025</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-soft-purple/10 to-lavender/10 rounded-2xl">
                <MapPin className="w-8 h-8 mx-auto mb-2 text-soft-purple" />
                <div className="text-3xl mb-2">📍</div>
                <h3 className="font-poppins font-semibold text-lg text-gray-800 mb-2">Main Venue</h3>
                <p className="text-gray-600 font-medium text-sm">H Block - Parking Area, SSA Society<br />Jain Park, Block A, Uttam Nagar, Delhi</p>
                <Button
                  asChild
                  size="sm"
                  className="mt-2 bg-birthday-pink text-white hover:bg-birthday-pink/90 rounded-full text-sm"
                >
                  <a href="https://maps.app.goo.gl/rbx48YRD2fMnwk3z6" target="_blank" rel="noopener noreferrer">
                    View on Map <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </Button>
              </div>
            </div>
          </div>

          {/* Google Map Section */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 mb-8 border border-pastel-pink/30">
            <h3 className="text-2xl font-poppins font-semibold text-center text-gray-800 mb-6">📍 Location Map</h3>
            <div className="relative w-full h-80 rounded-2xl overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.864!2d77.063267!3d28.608237!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b1b1b1b1b1b%3A0x1b1b1b1b1b1b1b1b!2sH%20Block%20-%20Parking%20Area%2C%20SSA%20Society%2C%20Jain%20Park%2C%20Block%20A%2C%20Uttam%20Nagar%2C%20Delhi!5e0!3m2!1sen!2sin!4v1653912345678!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="rounded-2xl"
                title="SSA Society H Block Parking Area - Birthday Venue Location"
              ></iframe>
            </div>
            <div className="text-center mt-4">
              <Button
                asChild
                size="sm"
                className="bg-birthday-pink text-white hover:bg-birthday-pink/90 rounded-full"
              >
                <a href="https://maps.app.goo.gl/rbx48YRD2fMnwk3z6" target="_blank" rel="noopener noreferrer">
                  Open in Google Maps <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </Button>
            </div>
          </div>

          {/* Welcome Message */}
          <div className="bg-gradient-to-r from-pastel-pink/20 via-lavender/20 to-cream/30 rounded-3xl p-8 mb-8">
            <h3 className="text-2xl font-poppins font-semibold text-gray-800 mb-4">💖 Welcome Message 💖</h3>
            <p className="text-lg text-gray-700 mb-4 leading-relaxed">
              Our little bundle of joy, Mayra, is turning TWO!
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              We're filled with love and gratitude, and we want you to be a part of this special day!
            </p>
          </div>

          {/* Quick Event Overview */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {quickEvents.map((event, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br ${event.bgColor} rounded-2xl p-6 text-center cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:scale-105`}
                onClick={() => setLocation(event.path)}
              >
                <div className="text-4xl mb-3">{event.emoji}</div>
                <h4 className="font-poppins font-semibold text-lg mb-2">{event.title}</h4>
                <p className="text-sm text-gray-600">{event.time}</p>
                <p className="text-xs text-gray-500">{event.subtitle}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
