import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import HomePage from "@/pages/HomePage";
import BhandaraPage from "@/pages/BhandaraPage";
import KirtanPage from "@/pages/KirtanPage";
import BirthdayPage from "@/pages/BirthdayPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-pink/20 via-lavender/20 to-cream/30">
      <Navigation />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/bhandara" component={BhandaraPage} />
        <Route path="/kirtan" component={KirtanPage} />
        <Route path="/birthday" component={BirthdayPage} />
        <Route component={NotFound} />
      </Switch>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
