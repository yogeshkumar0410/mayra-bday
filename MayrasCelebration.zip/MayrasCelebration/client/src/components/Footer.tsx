import { Phone, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-white/90 backdrop-blur-sm border-t border-pastel-pink/30 mt-12">
      <div className="max-w-4xl mx-auto px-4 py-8 text-center">
        {/* Closing Message */}
        <div className="mb-6">
          <h3 className="text-xl font-poppins font-semibold text-gray-800 mb-4">💫 Special Message 💫</h3>
          <p className="text-gray-700 mb-3 leading-relaxed">
            "Your presence will make Mayra's day even more special."
          </p>
          <p className="text-gray-700 font-medium">
            "Come with blessings and love!"
          </p>
        </div>

        {/* RSVP Section */}
        <div className="bg-gradient-to-r from-pastel-pink/20 to-lavender/20 rounded-2xl p-6 mb-6">
          <h4 className="font-poppins font-semibold text-lg text-gray-800 mb-3">📞 Contact for Details</h4>
          <p className="text-gray-600 mb-4">Please confirm your attendance</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sm text-gray-700">
            <div className="flex items-center gap-2 bg-white/50 px-4 py-2 rounded-full">
              <Phone className="w-4 h-4 text-birthday-pink" />
              <span className="font-medium">9015599070</span>
            </div>
            <div className="flex items-center gap-2 bg-white/50 px-4 py-2 rounded-full">
              <Phone className="w-4 h-4 text-birthday-pink" />
              <span className="font-medium">9315892485</span>
            </div>
          </div>
          <p className="text-gray-500 text-xs mt-3">Call or WhatsApp for RSVP</p>
        </div>

        {/* Family Sign-off */}
        <div className="border-t border-pastel-pink/30 pt-6">
          <p className="text-lg font-poppins font-semibold text-birthday-pink mb-2">
            ❤️ With warm regards
          </p>
          <p className="text-gray-700 font-medium">
            Dhakad Family | Yogesh & Kanchan
          </p>
          <p className="text-gray-600 mt-1">
            Love from Aryam 💕
          </p>
        </div>
      </div>
    </footer>
  );
}
