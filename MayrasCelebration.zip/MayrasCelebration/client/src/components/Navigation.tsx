import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, Flower, Mic, PartyPopper } from "lucide-react";

export default function Navigation() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/", label: "🏠 Home", icon: Home },
    { path: "/bhandara", label: "🌼 Bhandara", icon: Flower },
    { path: "/kirtan", label: "🎤 Kirtan", icon: Mic },
    { path: "/birthday", label: "🎉 Birthday", icon: PartyPopper },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md shadow-lg border-b border-pastel-pink/20">
      <div className="max-w-6xl mx-auto px-4 py-3">
        <div className="flex flex-wrap justify-center gap-2 md:gap-4">
          {navItems.map((item) => (
            <Button
              key={item.path}
              onClick={() => setLocation(item.path)}
              variant={location === item.path ? "default" : "outline"}
              size="sm"
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                location === item.path
                  ? "bg-birthday-pink text-white shadow-lg hover:bg-birthday-pink/90"
                  : "bg-white text-gray-600 hover:bg-birthday-pink hover:text-white border-gray-200"
              }`}
            >
              {item.label}
            </Button>
          ))}
        </div>
      </div>
    </nav>
  );
}
